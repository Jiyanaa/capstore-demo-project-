import { Component, OnInit } from '@angular/core';
import { LoginService } from '../login.service'

@Component({
  selector: 'app-deliverystatus',
  templateUrl: './deliverystatus.component.html',
  styleUrls: ['./deliverystatus.component.css']
})
export class DeliverystatusComponent implements OnInit {
  result: any
  status: any
  submitted = false;
  deliveryStatus
  constructor(private service: LoginService) { }

  ngOnInit() {
    this.showorder()
  }
  showorder(): void {
    this.service.vieworders().subscribe(data => {
      this.result = data;
      this.submitted = true;
      console.log(this.result);
    });
    
  }
  changeStatus(order_id) {
    this.service.updateStatus(order_id).subscribe(data => {
      this.status = data;
    });
    window.location.reload();
  }
}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagemerchantComponent } from './managemerchant.component';

describe('ManagemerchantComponent', () => {
  let component: ManagemerchantComponent;
  let fixture: ComponentFixture<ManagemerchantComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManagemerchantComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagemerchantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

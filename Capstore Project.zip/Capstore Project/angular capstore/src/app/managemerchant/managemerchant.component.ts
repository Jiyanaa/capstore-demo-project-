import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-managemerchant',
  templateUrl: './managemerchant.component.html',
  styleUrls: ['./managemerchant.component.css']
})
export class ManagemerchantComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

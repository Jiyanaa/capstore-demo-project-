import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowallmerchantsComponent } from './showallmerchants.component';

describe('ShowallmerchantsComponent', () => {
  let component: ShowallmerchantsComponent;
  let fixture: ComponentFixture<ShowallmerchantsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShowallmerchantsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowallmerchantsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

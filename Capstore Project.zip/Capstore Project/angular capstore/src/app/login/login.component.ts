import { Component, OnInit } from '@angular/core';
import { LoginService } from '../login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  result: any;
  model;
  constructor(private router: Router, private service: LoginService) { }
  a: any;
  
  ngOnInit() {
  }
  login(add) {
    if (add.email != null && add.password != null) {
      if (add.choice == "admin") {
        this.service.adminlogin(add).subscribe(data => {
          this.result = data
          if (this.result == "Login Successful") {
            
            this.router.navigate(['/adminmanage'])
          }
          else {
            console.log(this.result)
            alert(this.result)
          }
        });
      }
      else if (add.choice == "merchant") {
        this.service.merchantLogin(add).subscribe(data => {
          this.result = data
          if (this.result == "Login Successful") {
            alert(this.result)
            this.router.navigate(['/managemerchant'])
          }
          else {
            console.log(this.result)
            alert(this.result)
          }
        });
      }
      else if(add.choice == "customer")
      {
        this.service.customerlogin(add).subscribe(data=>{
          this.result=data
          if(this.result=="Login Successful"){
              alert(this.result)
              this.router.navigate(['/displayproducts'])
          }
          else{
            console.log(this.result)
            alert(this.result)
            }
        });
      }
      else{
        alert("Please choose an option")
      }
    }
    else{
      alert("Values cannot be empty")
    }
  }
}

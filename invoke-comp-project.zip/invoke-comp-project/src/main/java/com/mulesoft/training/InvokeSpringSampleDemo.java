package com.mulesoft.training;

import org.springframework.stereotype.Component;

@Component
public class InvokeSpringSampleDemo {
	
	public InvokeSpringSampleDemo() {
		// TODO Auto-generated constructor stub
	}
	
	public int doAddition(int num1, int num2) {
		return num1 + num2;
	}
	
	public int doSubtraction(int num1, int num2) {
		return num1 - num2;
	}
	
	public int doMultiplication(int num1, int num2) {
		return num1 * num2;
	}
	
	public int doDivision(int num1, int num2) {
		return num1 / num2;
	}

}
